# Gerar o APK na nuvem

Este projeto já inclui um GitHub Actions que prepara a estrutura Android, instala as dependências, gera os arquivos do Isar e compila o APK.

## Passo a passo

1. Crie uma conta no GitHub, caso ainda não tenha.
2. Crie um repositório novo, por exemplo `ap-materiais-graficas`.
3. Extraia este ZIP no celular/computador e envie **os arquivos e pastas do projeto** para o repositório (não envie apenas o ZIP).
4. Ao terminar o envio, abra a aba **Actions** do GitHub.
5. Entre em **Gerar APK Android**.
6. Se necessário, use **Run workflow** para iniciar manualmente.
7. Quando terminar, abra a execução concluída e procure **Artifacts**.
8. Baixe `AP-Materiais-Graficas-APK` e extraia o `app-release.apk`.

O APK é uma compilação de release para instalação/teste. Para publicar na Google Play, ainda é necessário configurar uma chave de assinatura própria.
