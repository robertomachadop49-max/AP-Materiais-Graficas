# AP Arts Paulh — Sistema de Vendas Offline

Base Flutter + Isar Community para uma gráfica, com foco em uso local no celular.

## Recursos
- Login local: `admin / 1234`
- Dashboard comercial
- Cadastro e busca de produtos
- Estoque e estoque mínimo
- Cadastro e busca de clientes
- Nova venda com carrinho e ajuste de quantidade
- Desconto, sinal/entrada e saldo a receber
- Formas de pagamento e status do pedido
- Histórico de pedidos
- Alteração de status
- Cancelamento com devolução automática do estoque
- Contas a receber e histórico de pagamentos
- Saídas de dinheiro
- Relatório mensal
- Pedido em JPEG
- Compartilhamento do pedido
- WhatsApp para enviar o texto do pedido
- Backup JSON dos dados
- Banco Isar local, sem servidor

## Abrir
```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs
flutter run
```

O WhatsApp é uma integração externa: o cadastro, estoque, vendas e financeiro funcionam offline, mas enviar uma mensagem pelo WhatsApp depende do próprio WhatsApp e de conexão disponível.
