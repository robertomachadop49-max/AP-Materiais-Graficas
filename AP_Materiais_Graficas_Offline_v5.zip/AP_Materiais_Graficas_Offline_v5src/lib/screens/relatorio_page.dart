import 'package:flutter/material.dart';
import '../database/database.dart';
import '../database/models/venda.dart';
import '../database/models/saida.dart';
import '../utils/formatters.dart';

class RelatorioPage extends StatefulWidget {
  const RelatorioPage({super.key});
  @override
  State<RelatorioPage> createState() => _RelatorioPageState();
}

class _RelatorioPageState extends State<RelatorioPage> {
  int mes = DateTime.now().month;
  int ano = DateTime.now().year;

  Future<Map<String, double>> calcular() async {
    final vendas = await DatabaseService.db.vendas.where().findAll();
    final saidas = await DatabaseService.db.saidas.where().findAll();
    final vm = vendas.where((v) => v.dataVenda.month == mes && v.dataVenda.year == ano).toList();
    final sm = saidas.where((s) => s.data.month == mes && s.data.year == ano).toList();

    double soma(Iterable<double> x) => x.fold(0, (a, b) => a + b);
    return {
      'pedidos': vm.length.toDouble(),
      'vendas': soma(vm.map((v) => v.total)),
      'descontos': soma(vm.map((v) => v.desconto)),
      'recebido': soma(vm.map((v) => v.valorPago)),
      'receber': soma(vm.map((v) => v.valorReceber)),
      'saidas': soma(sm.map((s) => s.valor)),
    };
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Relatório mensal')),
    body: FutureBuilder<Map<String, double>>(
      future: calcular(),
      builder: (_, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final r = s.data!;
        final resultado = r['vendas']! - r['saidas']!;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                Expanded(child: DropdownButtonFormField<int>(
                  value: mes,
                  decoration: const InputDecoration(labelText: 'Mês'),
                  items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))),
                  onChanged: (v) => setState(() => mes = v!),
                )),
                const SizedBox(width: 12),
                Expanded(child: TextFormField(
                  initialValue: '$ano',
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Ano'),
                  onChanged: (v) => ano = int.tryParse(v) ?? ano,
                )),
              ]),
            )),
            _card('Pedidos', '${r['pedidos']!.toInt()}', Icons.receipt_long),
            _card('Faturamento', brl(r['vendas']!), Icons.trending_up),
            _card('Descontos', brl(r['descontos']!), Icons.local_offer),
            _card('Recebido', brl(r['recebido']!), Icons.payments),
            _card('A receber', brl(r['receber']!), Icons.schedule),
            _card('Saídas', brl(r['saidas']!), Icons.money_off),
            _card('Resultado', brl(resultado), Icons.account_balance),
          ],
        );
      },
    ),
  );

  Widget _card(String t, String v, IconData icon) => Card(
    child: ListTile(
      leading: CircleAvatar(child: Icon(icon)),
      title: Text(t),
      trailing: Text(v, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    ),
  );
}
