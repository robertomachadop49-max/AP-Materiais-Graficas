import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../database/database.dart';
import '../database/models/venda.dart';
import '../services/pedido_jpeg_service.dart';
import '../services/venda_service.dart';
import '../services/whatsapp_service.dart';
import '../utils/formatters.dart';

class PedidoDetalhePage extends StatefulWidget {
  final Venda venda;
  const PedidoDetalhePage({super.key, required this.venda});
  @override State<PedidoDetalhePage> createState() => _PedidoDetalhePageState();
}

class _PedidoDetalhePageState extends State<PedidoDetalhePage> {
  late Venda venda;
  bool busy = false;
  @override void initState() { super.initState(); venda = widget.venda; }

  Future<void> update() async {
    await DatabaseService.db.writeTxn(() async => DatabaseService.db.vendas.put(venda));
    if (mounted) setState(() {});
  }

  Future<void> cancelar() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Cancelar pedido?'),
      content: const Text('O estoque dos itens será devolvido automaticamente.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('NÃO')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('SIM, CANCELAR')),
      ],
    ));
    if (ok != true) return;
    setState(() => busy = true);
    try {
      await VendaService().cancelar(venda);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pedido cancelado e estoque devolvido.')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> compartilhar() async {
    final file = await PedidoJpegService.gerar(venda);
    await SharePlus.instance.share(ShareParams(text: 'Pedido ${venda.numeroPedido} - AP Arts Paulh', files: [XFile(file.path)]));
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(venda.numeroPedido)),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(venda.clienteNome.isEmpty ? 'Cliente não informado' : venda.clienteNome, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...venda.itens.map((i) => ListTile(contentPadding: EdgeInsets.zero, title: Text(i.produtoNome), subtitle: Text('${i.quantidade} x ${brl(i.precoUnitario)}'), trailing: Text(brl(i.subtotal)))),
        const Divider(), _r('Subtotal', venda.subtotal), _r('Desconto', venda.desconto), _r('Total', venda.total, bold: true), _r('Sinal', venda.sinal), _r('A receber', venda.valorReceber, bold: true),
        const SizedBox(height: 10),
        Text('Status: ${venda.status.name.toUpperCase()}'), Text('Pagamento: ${venda.formaPagamento.name.toUpperCase()}'),
      ]))),
      DropdownButtonFormField<StatusPedido>(
        value: venda.status,
        decoration: const InputDecoration(labelText: 'Status do pedido'),
        items: StatusPedido.values.map((e) => DropdownMenuItem(value: e, child: Text(e.name.toUpperCase()))).toList(),
        onChanged: venda.status == StatusPedido.cancelado ? null : (novo) async { if (novo != null) { venda.status = novo; await update(); } },
      ),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: busy ? null : compartilhar, icon: const Icon(Icons.image), label: const Text('GERAR E COMPARTILHAR JPEG')),
      OutlinedButton.icon(onPressed: busy ? null : () async { try { await WhatsAppService.enviar(venda); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'))); } }, icon: const Icon(Icons.chat), label: const Text('ENVIAR TEXTO PELO WHATSAPP')),
      if (venda.status != StatusPedido.cancelado) OutlinedButton.icon(onPressed: busy ? null : cancelar, icon: const Icon(Icons.cancel), label: const Text('CANCELAR PEDIDO')),
    ]),
  );

  Widget _r(String t, double v, {bool bold = false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(t, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)), Text(brl(v), style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: bold ? 18 : 14))]));
}
