import 'package:flutter/material.dart';
import '../database/database.dart';
import '../database/models/cliente.dart';

class ClienteFormPage extends StatefulWidget {
  final Cliente? cliente;
  const ClienteFormPage({super.key, this.cliente});

  @override
  State<ClienteFormPage> createState() => _ClienteFormPageState();
}

class _ClienteFormPageState extends State<ClienteFormPage> {
  late final TextEditingController nome, telefone, cpf, endereco, obs;

  @override
  void initState() {
    super.initState();
    final c = widget.cliente;
    nome = TextEditingController(text: c?.nome ?? '');
    telefone = TextEditingController(text: c?.telefone ?? '');
    cpf = TextEditingController(text: c?.cpfCnpj ?? '');
    endereco = TextEditingController(text: c?.endereco ?? '');
    obs = TextEditingController(text: c?.observacao ?? '');
  }

  Future<void> salvar() async {
    if (nome.text.trim().isEmpty) return;
    final c = widget.cliente ?? Cliente();
    c.nome = nome.text.trim();
    c.telefone = telefone.text.trim();
    c.cpfCnpj = cpf.text.trim();
    c.endereco = endereco.text.trim();
    c.observacao = obs.text.trim();
    await DatabaseService.db.writeTxn(() async => DatabaseService.db.clientes.put(c));
    if (mounted) Navigator.pop(context);
  }

  Widget f(TextEditingController c, String label, {int maxLines = 1}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          maxLines: maxLines,
          decoration: InputDecoration(labelText: label),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.cliente == null ? 'Novo cliente' : 'Editar cliente')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        f(nome, 'Nome *'),
        f(telefone, 'WhatsApp / Telefone'),
        f(cpf, 'CPF / CNPJ'),
        f(endereco, 'Endereço'),
        f(obs, 'Observações', maxLines: 3),
        FilledButton.icon(
          onPressed: salvar,
          icon: const Icon(Icons.save),
          label: const Text('SALVAR CLIENTE'),
        ),
      ],
    ),
  );
}
