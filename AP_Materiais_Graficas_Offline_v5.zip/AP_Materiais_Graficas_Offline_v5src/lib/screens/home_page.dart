import 'package:flutter/material.dart';
import '../database/database.dart';
import '../database/models/produto.dart';
import '../database/models/cliente.dart';
import '../database/models/venda.dart';
import '../utils/formatters.dart';
import 'produto_form_page.dart';
import 'cliente_form_page.dart';
import 'financeiro_page.dart';
import 'relatorio_page.dart';
import 'pedido_detalhe_page.dart';
import 'venda_page.dart';
import 'pagamentos_page.dart';
import 'configuracoes_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;

  Future<Map<String, dynamic>> resumo() async {
    final db = DatabaseService.db;
    final produtos = await db.produtos.where().findAll();
    final clientes = await db.clientes.where().findAll();
    final vendas = await db.vendas.where().findAll();
    final hoje = DateTime.now();
    final mes = vendas.where((v) => v.dataVenda.year == hoje.year && v.dataVenda.month == hoje.month).toList();
    final total = mes.fold<double>(0, (s, v) => s + v.total);
    final receber = mes.fold<double>(0, (s, v) => s + v.valorReceber);
    final estoqueBaixo = produtos.where((p) => p.estoque <= p.estoqueMinimo).length;
    return {'produtos': produtos.length, 'clientes': clientes.length, 'pedidos': mes.length, 'total': total, 'receber': receber, 'estoqueBaixo': estoqueBaixo};
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_dashboard(), const ProdutosPage(), const ClientesPage(), const HistoricoPage()];
    return Scaffold(
      appBar: AppBar(
        title: const Text('AP Arts Paulh'),
        actions: [
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ConfiguracoesPage())), icon: const Icon(Icons.settings)),
        ],
      ),
      drawer: Drawer(
        child: ListView(padding: EdgeInsets.zero, children: [
          DrawerHeader(
            decoration: const BoxDecoration(color: Color(0xFF009FE3)),
            child: Image.asset('assets/logo.png'),
          ),
          ListTile(leading: const Icon(Icons.point_of_sale), title: const Text('Nova venda'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VendaPage()))),
          ListTile(leading: const Icon(Icons.account_balance_wallet), title: const Text('Financeiro / A receber / Saídas'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FinanceiroPage()))),
          ListTile(leading: const Icon(Icons.payments), title: const Text('Histórico de pagamentos'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PagamentosPage()))),
          ListTile(leading: const Icon(Icons.bar_chart), title: const Text('Relatório mensal'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RelatorioPage()))),
          ListTile(leading: const Icon(Icons.backup), title: const Text('Backup'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ConfiguracoesPage()))),
        ]),
      ),
      body: pages[tab],
      floatingActionButton: (tab == 1 || tab == 2) ? FloatingActionButton(
        onPressed: () async {
          if (tab == 1) {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProdutoFormPage()));
          } else {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const ClienteFormPage()));
          }
          setState(() {});
        },
        child: const Icon(Icons.add),
      ) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Produtos'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Clientes'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Pedidos'),
        ],
      ),
    );
  }

  Widget _dashboard() => FutureBuilder<Map<String, dynamic>>(
    future: resumo(),
    builder: (_, s) {
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final r = s.data!;
      return RefreshIndicator(
        onRefresh: () async => setState(() {}),
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/logo.png', width: 86, height: 86, fit: BoxFit.contain)),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('AP Arts Paulh', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              Text('Produções Gráficas', style: TextStyle(fontSize: 14)),
              SizedBox(height: 6),
              Text('Sistema de vendas offline', style: TextStyle(fontSize: 12)),
            ])),
          ]))),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _metric('Vendas', brl(r['total']), Icons.trending_up)),
            const SizedBox(width: 10),
            Expanded(child: _metric('Pedidos', '${r['pedidos']}', Icons.receipt_long)),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _metric('A receber', brl(r['receber']), Icons.schedule)),
            const SizedBox(width: 10),
            Expanded(child: _metric('Estoque baixo', '${r['estoqueBaixo']}', Icons.warning_amber)),
          ]),
          const SizedBox(height: 16),
          const Text('Acesso rápido', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _action('Nova venda', Icons.add_shopping_cart, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VendaPage())))),
            const SizedBox(width: 10),
            Expanded(child: _action('Financeiro', Icons.account_balance_wallet, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FinanceiroPage())))),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _action('Relatório', Icons.bar_chart, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RelatorioPage())))),
            const SizedBox(width: 10),
            Expanded(child: _action('Pagamentos', Icons.payments, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PagamentosPage())))),
          ]),
        ]),
      );
    },
  );

  Widget _metric(String title, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
    Icon(icon, size: 27),
    const SizedBox(height: 5),
    Text(title, style: const TextStyle(fontSize: 12)),
    Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
  ])));

  Widget _action(String title, IconData icon, VoidCallback fn) => FilledButton.tonalIcon(onPressed: fn, icon: Icon(icon), label: Text(title));
}

class ProdutosPage extends StatefulWidget {
  const ProdutosPage({super.key});
  @override State<ProdutosPage> createState() => _ProdutosPageState();
}
class _ProdutosPageState extends State<ProdutosPage> {
  String q = '';
  Future<List<Produto>> load() => DatabaseService.db.produtos.where().sortByNome().findAll();
  @override Widget build(BuildContext context) => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(12,12,12,4), child: TextField(
      onChanged: (v) => setState(() => q = v.toLowerCase()),
      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar produto...'),
    )),
    Expanded(child: FutureBuilder<List<Produto>>(future: load(), builder: (_, s) {
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final lista = s.data!.where((p) => p.nome.toLowerCase().contains(q) || p.codigo.toLowerCase().contains(q)).toList();
      if (lista.isEmpty) return const Center(child: Text('Nenhum produto encontrado.'));
      return ListView.builder(padding: const EdgeInsets.all(12), itemCount: lista.length, itemBuilder: (_, i) {
        final p = lista[i];
        return Card(child: ListTile(
          leading: CircleAvatar(child: Icon(p.estoque <= p.estoqueMinimo ? Icons.warning : Icons.inventory_2)),
          title: Text(p.nome),
          subtitle: Text('${brl(p.preco)} • Estoque: ${p.estoque}'),
          onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => ProdutoFormPage(produto: p))); setState(() {}); },
        ));
      });
    })),
  ]);
}

class ClientesPage extends StatefulWidget {
  const ClientesPage({super.key});
  @override State<ClientesPage> createState() => _ClientesPageState();
}
class _ClientesPageState extends State<ClientesPage> {
  String q = '';
  Future<List<Cliente>> load() => DatabaseService.db.clientes.where().sortByNome().findAll();
  @override Widget build(BuildContext context) => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(12,12,12,4), child: TextField(
      onChanged: (v) => setState(() => q = v.toLowerCase()),
      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar cliente...'),
    )),
    Expanded(child: FutureBuilder<List<Cliente>>(future: load(), builder: (_, s) {
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final lista = s.data!.where((c) => c.nome.toLowerCase().contains(q) || c.telefone.toLowerCase().contains(q)).toList();
      return ListView.builder(padding: const EdgeInsets.all(12), itemCount: lista.length, itemBuilder: (_, i) {
        final c = lista[i];
        return Card(child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(c.nome),
          subtitle: Text(c.telefone.isEmpty ? 'Sem telefone' : c.telefone),
          onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => ClienteFormPage(cliente: c))); setState(() {}); },
        ));
      });
    })),
  ]);
}

class HistoricoPage extends StatefulWidget {
  const HistoricoPage({super.key});
  @override State<HistoricoPage> createState() => _HistoricoPageState();
}
class _HistoricoPageState extends State<HistoricoPage> {
  String q = '';
  Future<List<Venda>> load() => DatabaseService.db.vendas.where().sortByDataVendaDesc().findAll();
  @override Widget build(BuildContext context) => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(12,12,12,4), child: TextField(
      onChanged: (v) => setState(() => q = v.toLowerCase()),
      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar pedido ou cliente...'),
    )),
    Expanded(child: FutureBuilder<List<Venda>>(future: load(), builder: (_, s) {
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final lista = s.data!.where((v) => v.numeroPedido.toLowerCase().contains(q) || v.clienteNome.toLowerCase().contains(q)).toList();
      if (lista.isEmpty) return const Center(child: Text('Nenhum pedido encontrado.'));
      return ListView.builder(padding: const EdgeInsets.all(12), itemCount: lista.length, itemBuilder: (_, i) {
        final v = lista[i];
        return Card(child: ListTile(
          title: Text(v.numeroPedido),
          subtitle: Text('${v.clienteNome.isEmpty ? 'Sem cliente' : v.clienteNome} • ${v.status.name.toUpperCase()}'),
          trailing: Text(brl(v.total), style: const TextStyle(fontWeight: FontWeight.bold)),
          onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => PedidoDetalhePage(venda: v))); setState(() {}); },
        ));
      });
    })),
  ]);
}
