import 'package:flutter/material.dart';
import '../database/database.dart';
import '../database/models/produto.dart';

class ProdutoFormPage extends StatefulWidget {
  final Produto? produto;
  const ProdutoFormPage({super.key, this.produto});
  @override
  State<ProdutoFormPage> createState() => _ProdutoFormPageState();
}

class _ProdutoFormPageState extends State<ProdutoFormPage> {
  late final TextEditingController nome, preco, estoque, minimo, codigo, categoria, tamanho, papel, gramatura, impressao, acabamento;

  @override
  void initState() {
    super.initState();
    final p = widget.produto;
    nome = TextEditingController(text: p?.nome ?? '');
    preco = TextEditingController(text: p?.preco.toString() ?? '');
    estoque = TextEditingController(text: p?.estoque.toString() ?? '0');
    minimo = TextEditingController(text: p?.estoqueMinimo.toString() ?? '0');
    codigo = TextEditingController(text: p?.codigo ?? '');
    categoria = TextEditingController(text: p?.categoria ?? '');
    tamanho = TextEditingController(text: p?.tamanho ?? '');
    papel = TextEditingController(text: p?.papel ?? '');
    gramatura = TextEditingController(text: p?.gramatura ?? '');
    impressao = TextEditingController(text: p?.impressao ?? '');
    acabamento = TextEditingController(text: p?.acabamento ?? '');
  }

  Future<void> salvar() async {
    final p = widget.produto ?? Produto();
    p.nome = nome.text.trim();
    p.preco = double.tryParse(preco.text.replaceAll(',', '.')) ?? 0;
    p.estoque = int.tryParse(estoque.text) ?? 0;
    p.estoqueMinimo = int.tryParse(minimo.text) ?? 0;
    p.codigo = codigo.text.trim();
    p.categoria = categoria.text.trim();
    p.tamanho = tamanho.text.trim();
    p.papel = papel.text.trim();
    p.gramatura = gramatura.text.trim();
    p.impressao = impressao.text.trim();
    p.acabamento = acabamento.text.trim();
    p.atualizadoEm = DateTime.now();

    await DatabaseService.db.writeTxn(() async => DatabaseService.db.produtos.put(p));
    if (mounted) Navigator.pop(context);
  }

  Widget field(TextEditingController c, String label, {TextInputType? type}) =>
      Padding(padding: const EdgeInsets.only(bottom: 12), child: TextField(controller: c, keyboardType: type, decoration: InputDecoration(labelText: label)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.produto == null ? 'Novo produto' : 'Editar produto')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        field(nome, 'Nome'),
        field(preco, 'Preço de venda', type: const TextInputType.numberWithOptions(decimal: true)),
        field(estoque, 'Estoque', type: TextInputType.number),
        field(minimo, 'Estoque mínimo', type: TextInputType.number),
        field(codigo, 'Código'),
        field(categoria, 'Categoria'),
        field(tamanho, 'Tamanho'),
        field(papel, 'Papel'),
        field(gramatura, 'Gramatura'),
        field(impressao, 'Impressão'),
        field(acabamento, 'Acabamento'),
        FilledButton.icon(onPressed: salvar, icon: const Icon(Icons.save), label: const Text('SALVAR')),
      ]),
    );
  }
}
