import 'package:flutter/material.dart';
import '../database/database.dart';
import '../database/models/pagamento.dart';
import '../utils/formatters.dart';

class PagamentosPage extends StatelessWidget {
  const PagamentosPage({super.key});

  Future<List<Pagamento>> load() =>
      DatabaseService.db.pagamentos.where().sortByDataDesc().findAll();

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Histórico de pagamentos')),
    body: FutureBuilder<List<Pagamento>>(
      future: load(),
      builder: (_, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.isEmpty) return const Center(child: Text('Nenhum pagamento registrado.'));
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: s.data!.length,
          itemBuilder: (_, i) {
            final p = s.data![i];
            return Card(child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.payments)),
              title: Text('Venda #${p.vendaId}'),
              subtitle: Text('${p.formaPagamento.name.toUpperCase()} • ${p.data.day.toString().padLeft(2,'0')}/${p.data.month.toString().padLeft(2,'0')}/${p.data.year}'),
              trailing: Text(brl(p.valor), style: const TextStyle(fontWeight: FontWeight.bold)),
            ));
          },
        );
      },
    ),
  );
}
