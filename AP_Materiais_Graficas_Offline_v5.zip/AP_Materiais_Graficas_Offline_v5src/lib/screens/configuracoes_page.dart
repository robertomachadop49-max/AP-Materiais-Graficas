import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'services_placeholder.dart';

class ConfiguracoesPage extends StatelessWidget {
  const ConfiguracoesPage({super.key});

  Future<void> backup(BuildContext context) async {
    final file = await BackupBridge.exportar();
    await SharePlus.instance.share(ShareParams(
      text: 'Backup AP Materiais Gráficas',
      files: [XFile(file.path)],
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Configurações')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(child: ListTile(
          leading: const Icon(Icons.backup),
          title: const Text('Backup dos dados'),
          subtitle: const Text('Gera um arquivo JSON para guardar ou compartilhar.'),
          onTap: () async {
            try {
              await backup(context);
            } catch (e) {
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
            }
          },
        )),
        const Card(child: ListTile(
          leading: Icon(Icons.wifi_off),
          title: Text('Modo offline'),
          subtitle: Text('Produtos, clientes, vendas e financeiro ficam no aparelho.'),
        )),
      ],
    ),
  );
}
