import 'dart:io';
import '../services/backup_service.dart';

class BackupBridge {
  static Future<File> exportar() => BackupService.exportar();
}
