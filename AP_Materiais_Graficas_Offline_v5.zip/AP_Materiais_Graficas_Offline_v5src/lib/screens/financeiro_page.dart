import 'package:flutter/material.dart';
import '../database/database.dart';
import '../database/models/saida.dart';
import '../database/models/pagamento.dart';
import '../database/models/venda.dart';
import '../utils/formatters.dart';

class FinanceiroPage extends StatefulWidget {
  const FinanceiroPage({super.key});
  @override
  State<FinanceiroPage> createState() => _FinanceiroPageState();
}

class _FinanceiroPageState extends State<FinanceiroPage> {
  int tab = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Financeiro')),
    body: tab == 0 ? const ReceberTab() : const SaidasTab(),
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab,
      onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.account_balance_wallet), label: 'A receber'),
        NavigationDestination(icon: Icon(Icons.money_off), label: 'Saídas'),
      ],
    ),
  );
}

class ReceberTab extends StatefulWidget {
  const ReceberTab({super.key});
  @override
  State<ReceberTab> createState() => _ReceberTabState();
}

class _ReceberTabState extends State<ReceberTab> {
  Future<List<Venda>> load() => DatabaseService.db.vendas.where().findAll();

  Future<void> pagar(Venda v) async {
    final controller = TextEditingController();
    final valor = await showDialog<double>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Receber ${v.numeroPedido}'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Valor recebido'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () => Navigator.pop(context, double.tryParse(controller.text.replaceAll(',', '.')) ?? 0),
            child: const Text('Receber'),
          ),
        ],
      ),
    );
    if (valor == null || valor <= 0) return;

    await DatabaseService.db.writeTxn(() async {
      v.valorPago += valor;
      v.valorReceber = (v.total - v.valorPago).clamp(0.0, double.infinity).toDouble();
      await DatabaseService.db.vendas.put(v);

      final p = Pagamento()
        ..vendaId = v.id
        ..clienteId = v.clienteId
        ..valor = valor
        ..formaPagamento = v.formaPagamento
        ..data = DateTime.now();
      await DatabaseService.db.pagamentos.put(p);
    });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Venda>>(
    future: load(),
    builder: (_, s) {
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final lista = s.data!.where((v) => v.valorReceber > 0).toList();
      if (lista.isEmpty) return const Center(child: Text('Nenhum valor pendente.'));
      return ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: lista.length,
        itemBuilder: (_, i) {
          final v = lista[i];
          return Card(
            child: ListTile(
              title: Text('${v.numeroPedido} • ${v.clienteNome}'),
              subtitle: Text('A receber: ${brl(v.valorReceber)}'),
              trailing: FilledButton(onPressed: () => pagar(v), child: const Text('RECEBER')),
            ),
          );
        },
      );
    },
  );
}

class SaidasTab extends StatefulWidget {
  const SaidasTab({super.key});
  @override
  State<SaidasTab> createState() => _SaidasTabState();
}

class _SaidasTabState extends State<SaidasTab> {
  Future<List<Saida>> load() => DatabaseService.db.saidas.where().sortByDataDesc().findAll();

  Future<void> novaSaida() async {
    final desc = TextEditingController();
    final valor = TextEditingController();
    final categoria = TextEditingController();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nova saída'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'Descrição')),
          TextField(controller: categoria, decoration: const InputDecoration(labelText: 'Categoria')),
          TextField(controller: valor, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Valor')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () async {
            final s = Saida()
              ..descricao = desc.text.trim()
              ..categoria = categoria.text.trim()
              ..valor = double.tryParse(valor.text.replaceAll(',', '.')) ?? 0;
            await DatabaseService.db.writeTxn(() async => DatabaseService.db.saidas.put(s));
            if (context.mounted) Navigator.pop(context);
            setState(() {});
          }, child: const Text('SALVAR')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    floatingActionButton: FloatingActionButton(onPressed: novaSaida, child: const Icon(Icons.add)),
    body: FutureBuilder<List<Saida>>(
      future: load(),
      builder: (_, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.isEmpty) return const Center(child: Text('Nenhuma saída cadastrada.'));
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: s.data!.length,
          itemBuilder: (_, i) {
            final x = s.data![i];
            return Card(child: ListTile(
              title: Text(x.descricao),
              subtitle: Text('${x.categoria} • ${x.data.day.toString().padLeft(2, '0')}/${x.data.month.toString().padLeft(2, '0')}/${x.data.year}'),
              trailing: Text(brl(x.valor)),
            ));
          },
        );
      },
    ),
  );
}
