import 'package:flutter/material.dart';
import 'database/database.dart';
import 'screens/login_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseService.init();
  runApp(const APApp());
}

class APApp extends StatelessWidget {
  const APApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AP Materiais Gráficas',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF009FE3),
        scaffoldBackgroundColor: const Color(0xFFF6F7F9),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      home: const LoginPage(),
    );
  }
}
