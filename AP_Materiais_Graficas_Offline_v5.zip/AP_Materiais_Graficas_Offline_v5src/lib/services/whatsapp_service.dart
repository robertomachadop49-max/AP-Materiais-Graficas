import 'package:url_launcher/url_launcher.dart';
import '../database/models/venda.dart';

class WhatsAppService {
  static Future<void> enviar(Venda venda) async {
    final linhas = <String>[
      'AP ARTS PAULH - PRODUÇÕES GRÁFICAS',
      'PEDIDO ${venda.numeroPedido}',
      '',
      'Cliente: ${venda.clienteNome.isEmpty ? 'Não informado' : venda.clienteNome}',
      '',
      ...venda.itens.map((i) =>
        '${i.quantidade}x ${i.produtoNome} - R\$ ${i.subtotal.toStringAsFixed(2)}'),
      '',
      'Subtotal: R\$ ${venda.subtotal.toStringAsFixed(2)}',
      'Desconto: R\$ ${venda.desconto.toStringAsFixed(2)}',
      'TOTAL: R\$ ${venda.total.toStringAsFixed(2)}',
      'Sinal: R\$ ${venda.sinal.toStringAsFixed(2)}',
      'A receber: R\$ ${venda.valorReceber.toStringAsFixed(2)}',
      'Status: ${venda.status.name.toUpperCase()}',
      'Pagamento: ${venda.formaPagamento.name}',
      '',
      venda.observacao,
    ];

    final text = Uri.encodeComponent(linhas.join('\n'));
    final uri = Uri.parse('whatsapp://send?text=$text');

    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('WhatsApp não está disponível neste aparelho.');
    }
  }
}
