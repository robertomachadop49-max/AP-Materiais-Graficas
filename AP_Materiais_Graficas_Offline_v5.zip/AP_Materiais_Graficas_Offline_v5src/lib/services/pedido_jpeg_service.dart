import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:screenshot/screenshot.dart';
import 'package:image/image.dart' as img;
import 'dart:io';
import '../database/models/venda.dart';
import '../utils/formatters.dart';

class PedidoJpegService {
  static Future<File> gerar(Venda venda) async {
    final controller = ScreenshotController();
    final bytes = await controller.captureFromWidget(
      _PedidoCard(venda: venda),
      pixelRatio: 2.0,
    );
    final decoded = img.decodeImage(Uint8List.fromList(bytes));
    if (decoded == null) throw Exception('Não foi possível gerar a imagem.');
    final jpg = img.encodeJpg(decoded, quality: 92);
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${venda.numeroPedido}.jpg');
    await file.writeAsBytes(jpg);
    return file;
  }
}

class _PedidoCard extends StatelessWidget {
  final Venda venda;
  const _PedidoCard({required this.venda});

  @override
  Widget build(BuildContext context) => Container(
    width: 900,
    padding: const EdgeInsets.all(40),
    color: Colors.white,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('AP ARTS PAULH', style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
      const Text('PRODUÇÕES GRÁFICAS', style: TextStyle(fontSize: 22)),
      const SizedBox(height: 20),
      Text('PEDIDO ${venda.numeroPedido}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      Text('Cliente: ${venda.clienteNome.isEmpty ? 'Não informado' : venda.clienteNome}', style: const TextStyle(fontSize: 20)),
      const Divider(),
      ...venda.itens.map((i) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('${i.quantidade}x ${i.produtoNome}', style: const TextStyle(fontSize: 20)),
          Text(brl(i.subtotal), style: const TextStyle(fontSize: 20)),
        ]),
      )),
      const Divider(),
      _r('Subtotal', venda.subtotal),
      _r('Desconto', venda.desconto),
      _r('TOTAL', venda.total, bold: true),
      _r('Sinal', venda.sinal),
      _r('A receber', venda.valorReceber, bold: true),
      const SizedBox(height: 20),
      Text('Status: ${venda.status.name.toUpperCase()}', style: const TextStyle(fontSize: 20)),
      Text('Pagamento: ${venda.formaPagamento.name.toUpperCase()}', style: const TextStyle(fontSize: 20)),
      if (venda.observacao.isNotEmpty) Text('Obs.: ${venda.observacao}', style: const TextStyle(fontSize: 18)),
    ]),
  );

  Widget _r(String t, double v, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(t, style: TextStyle(fontSize: 21, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      Text(brl(v), style: TextStyle(fontSize: 21, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
    ]),
  );
}
