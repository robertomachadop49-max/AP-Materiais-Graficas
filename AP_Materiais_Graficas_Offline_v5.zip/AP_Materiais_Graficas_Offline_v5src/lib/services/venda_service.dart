import '../database/database.dart';
import '../database/models/venda.dart';

class VendaService {
  Future<void> cancelar(Venda venda) async {
    if (venda.status == StatusPedido.cancelado) return;
    final db = DatabaseService.db;
    await db.writeTxn(() async {
      for (final item in venda.itens) {
        final produto = await db.produtos.get(item.produtoId);
        if (produto != null) {
          produto.estoque += item.quantidade;
          produto.atualizadoEm = DateTime.now();
          await db.produtos.put(produto);
        }
      }
      venda.status = StatusPedido.cancelado;
      venda.valorReceber = 0;
      await db.vendas.put(venda);
    });
  }

  Future<int> finalizar(Venda venda) async {
    final db = DatabaseService.db;

    late int id;

    await db.writeTxn(() async {
      for (final item in venda.itens) {
        final produto = await db.produtos.get(item.produtoId);
        if (produto == null) throw Exception('Produto não encontrado.');
        if (produto.estoque < item.quantidade) {
          throw Exception('Estoque insuficiente para ${produto.nome}.');
        }
      }

      for (final item in venda.itens) {
        final produto = await db.produtos.get(item.produtoId);
        if (produto != null) {
          produto.estoque -= item.quantidade;
          produto.atualizadoEm = DateTime.now();
          await db.produtos.put(produto);
        }
      }

      venda.subtotal = venda.itens.fold(0, (s, i) => s + i.subtotal);
      venda.total = (venda.subtotal - venda.desconto).clamp(0.0, double.infinity).toDouble();
      venda.valorPago = venda.sinal;
      venda.valorReceber = (venda.total - venda.valorPago).clamp(0.0, double.infinity).toDouble();
      venda.numeroPedido = 'PED-${DateTime.now().millisecondsSinceEpoch}';
      venda.dataVenda = DateTime.now();

      id = await db.vendas.put(venda);
    });

    return id;
  }
}
