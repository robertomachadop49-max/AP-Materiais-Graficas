import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../database/database.dart';
import '../database/models/produto.dart';
import '../database/models/cliente.dart';
import '../database/models/venda.dart';
import '../database/models/venda_item.dart';
import '../database/models/pagamento.dart';
import '../database/models/saida.dart';

class BackupService {
  static Future<File> exportar() async {
    final db = DatabaseService.db;
    final produtos = await db.produtos.where().findAll();
    final clientes = await db.clientes.where().findAll();
    final vendas = await db.vendas.where().findAll();
    final pagamentos = await db.pagamentos.where().findAll();
    final saidas = await db.saidas.where().findAll();

    final data = {
      'versao': 1,
      'exportadoEm': DateTime.now().toIso8601String(),
      'produtos': produtos.map((p) => {
        'id': p.id, 'nome': p.nome, 'preco': p.preco, 'custo': p.custo,
        'estoque': p.estoque, 'estoqueMinimo': p.estoqueMinimo, 'codigo': p.codigo,
        'categoria': p.categoria, 'tamanho': p.tamanho, 'papel': p.papel,
        'gramatura': p.gramatura, 'impressao': p.impressao, 'acabamento': p.acabamento,
        'ativo': p.ativo, 'criadoEm': p.criadoEm.toIso8601String(),
        'atualizadoEm': p.atualizadoEm.toIso8601String(),
      }).toList(),
      'clientes': clientes.map((c) => {
        'id': c.id, 'nome': c.nome, 'telefone': c.telefone, 'cpfCnpj': c.cpfCnpj,
        'endereco': c.endereco, 'observacao': c.observacao,
        'criadoEm': c.criadoEm.toIso8601String(),
      }).toList(),
      'vendas': vendas.map((v) => {
        'id': v.id, 'numeroPedido': v.numeroPedido, 'clienteId': v.clienteId,
        'clienteNome': v.clienteNome,
        'itens': v.itens.map((i) => {
          'produtoId': i.produtoId, 'produtoNome': i.produtoNome,
          'quantidade': i.quantidade, 'precoUnitario': i.precoUnitario,
          'subtotal': i.subtotal,
        }).toList(),
        'subtotal': v.subtotal, 'desconto': v.desconto, 'total': v.total,
        'sinal': v.sinal, 'valorPago': v.valorPago, 'valorReceber': v.valorReceber,
        'status': v.status.index, 'formaPagamento': v.formaPagamento.index,
        'observacao': v.observacao, 'dataVenda': v.dataVenda.toIso8601String(),
        'dataEntrega': v.dataEntrega?.toIso8601String(),
      }).toList(),
      'pagamentos': pagamentos.map((p) => {
        'id': p.id, 'vendaId': p.vendaId, 'clienteId': p.clienteId,
        'valor': p.valor, 'formaPagamento': p.formaPagamento.index,
        'data': p.data.toIso8601String(), 'observacao': p.observacao,
      }).toList(),
      'saidas': saidas.map((s) => {
        'id': s.id, 'descricao': s.descricao, 'valor': s.valor,
        'categoria': s.categoria, 'data': s.data.toIso8601String(),
        'observacao': s.observacao,
      }).toList(),
    };

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/backup_ap_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    return file;
  }

  static Future<void> importar(File file) async {
    final raw = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
    final db = DatabaseService.db;

    await db.writeTxn(() async {
      for (final x in (raw['produtos'] as List? ?? [])) {
        final p = Produto()
          ..id = x['id'] as int
          ..nome = x['nome'] ?? ''
          ..preco = (x['preco'] as num?)?.toDouble() ?? 0
          ..custo = (x['custo'] as num?)?.toDouble() ?? 0
          ..estoque = x['estoque'] ?? 0
          ..estoqueMinimo = x['estoqueMinimo'] ?? 0
          ..codigo = x['codigo'] ?? ''
          ..categoria = x['categoria'] ?? ''
          ..tamanho = x['tamanho'] ?? ''
          ..papel = x['papel'] ?? ''
          ..gramatura = x['gramatura'] ?? ''
          ..impressao = x['impressao'] ?? ''
          ..acabamento = x['acabamento'] ?? ''
          ..ativo = x['ativo'] ?? true
          ..criadoEm = DateTime.tryParse(x['criadoEm'] ?? '') ?? DateTime.now()
          ..atualizadoEm = DateTime.tryParse(x['atualizadoEm'] ?? '') ?? DateTime.now();
        await db.produtos.put(p);
      }

      for (final x in (raw['clientes'] as List? ?? [])) {
        final c = Cliente()
          ..id = x['id'] as int
          ..nome = x['nome'] ?? ''
          ..telefone = x['telefone'] ?? ''
          ..cpfCnpj = x['cpfCnpj'] ?? ''
          ..endereco = x['endereco'] ?? ''
          ..observacao = x['observacao'] ?? ''
          ..criadoEm = DateTime.tryParse(x['criadoEm'] ?? '') ?? DateTime.now();
        await db.clientes.put(c);
      }

      for (final x in (raw['vendas'] as List? ?? [])) {
        final v = Venda()
          ..id = x['id'] as int
          ..numeroPedido = x['numeroPedido'] ?? ''
          ..clienteId = x['clienteId']
          ..clienteNome = x['clienteNome'] ?? ''
          ..subtotal = (x['subtotal'] as num?)?.toDouble() ?? 0
          ..desconto = (x['desconto'] as num?)?.toDouble() ?? 0
          ..total = (x['total'] as num?)?.toDouble() ?? 0
          ..sinal = (x['sinal'] as num?)?.toDouble() ?? 0
          ..valorPago = (x['valorPago'] as num?)?.toDouble() ?? 0
          ..valorReceber = (x['valorReceber'] as num?)?.toDouble() ?? 0
          ..status = StatusPedido.values[(x['status'] as int?) ?? 0]
          ..formaPagamento = FormaPagamento.values[(x['formaPagamento'] as int?) ?? 0]
          ..observacao = x['observacao'] ?? ''
          ..dataVenda = DateTime.tryParse(x['dataVenda'] ?? '') ?? DateTime.now()
          ..dataEntrega = x['dataEntrega'] == null ? null : DateTime.tryParse(x['dataEntrega']);
        v.itens = ((x['itens'] as List?) ?? []).map((i) => VendaItem()
          ..produtoId = i['produtoId'] ?? 0
          ..produtoNome = i['produtoNome'] ?? ''
          ..quantidade = i['quantidade'] ?? 0
          ..precoUnitario = (i['precoUnitario'] as num?)?.toDouble() ?? 0
          ..subtotal = (i['subtotal'] as num?)?.toDouble() ?? 0).toList();
        await db.vendas.put(v);
      }

      for (final x in (raw['pagamentos'] as List? ?? [])) {
        final p = Pagamento()
          ..id = x['id'] as int
          ..vendaId = x['vendaId'] ?? 0
          ..clienteId = x['clienteId']
          ..valor = (x['valor'] as num?)?.toDouble() ?? 0
          ..formaPagamento = FormaPagamento.values[(x['formaPagamento'] as int?) ?? 0]
          ..data = DateTime.tryParse(x['data'] ?? '') ?? DateTime.now()
          ..observacao = x['observacao'] ?? '';
        await db.pagamentos.put(p);
      }

      for (final x in (raw['saidas'] as List? ?? [])) {
        final s = Saida()
          ..id = x['id'] as int
          ..descricao = x['descricao'] ?? ''
          ..valor = (x['valor'] as num?)?.toDouble() ?? 0
          ..categoria = x['categoria'] ?? ''
          ..data = DateTime.tryParse(x['data'] ?? '') ?? DateTime.now()
          ..observacao = x['observacao'] ?? '';
        await db.saidas.put(s);
      }
    });
  }
}
