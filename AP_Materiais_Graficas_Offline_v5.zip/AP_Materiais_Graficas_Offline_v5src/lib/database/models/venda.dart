import 'package:isar_community/isar.dart';
import 'venda_item.dart';

part 'venda.g.dart';

enum StatusPedido { pendente, confirmado, producao, pronto, entregue, cancelado }
enum FormaPagamento { dinheiro, pix, credito, debito, boleto, transferencia, fiado, outro }

@collection
class Venda {
  Id id = Isar.autoIncrement;

  @Index()
  String numeroPedido = '';

  int? clienteId;
  String clienteNome = '';

  List<VendaItem> itens = [];

  double subtotal = 0;
  double desconto = 0;
  double total = 0;
  double sinal = 0;
  double valorPago = 0;
  double valorReceber = 0;

  @enumerated
  StatusPedido status = StatusPedido.pendente;

  @enumerated
  FormaPagamento formaPagamento = FormaPagamento.pix;

  String observacao = '';
  DateTime dataVenda = DateTime.now();
  DateTime? dataEntrega;
}
