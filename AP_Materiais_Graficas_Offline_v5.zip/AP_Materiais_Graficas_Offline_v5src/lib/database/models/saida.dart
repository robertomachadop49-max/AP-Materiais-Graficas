import 'package:isar_community/isar.dart';

part 'saida.g.dart';

@collection
class Saida {
  Id id = Isar.autoIncrement;
  String descricao = '';
  double valor = 0;
  String categoria = '';
  DateTime data = DateTime.now();
  String observacao = '';
}
