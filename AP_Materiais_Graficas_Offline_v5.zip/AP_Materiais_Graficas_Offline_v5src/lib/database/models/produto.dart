import 'package:isar_community/isar.dart';

part 'produto.g.dart';

@collection
class Produto {
  Id id = Isar.autoIncrement;

  @Index()
  String nome = '';

  double preco = 0;
  double custo = 0;
  int estoque = 0;
  int estoqueMinimo = 0;

  String codigo = '';
  String categoria = '';
  String tamanho = '';
  String papel = '';
  String gramatura = '';
  String impressao = '';
  String acabamento = '';

  bool ativo = true;
  DateTime criadoEm = DateTime.now();
  DateTime atualizadoEm = DateTime.now();
}
