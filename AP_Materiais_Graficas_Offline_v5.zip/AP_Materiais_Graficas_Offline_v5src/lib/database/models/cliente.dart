import 'package:isar_community/isar.dart';

part 'cliente.g.dart';

@collection
class Cliente {
  Id id = Isar.autoIncrement;

  @Index()
  String nome = '';

  String telefone = '';
  String cpfCnpj = '';
  String endereco = '';
  String observacao = '';
  DateTime criadoEm = DateTime.now();
}
