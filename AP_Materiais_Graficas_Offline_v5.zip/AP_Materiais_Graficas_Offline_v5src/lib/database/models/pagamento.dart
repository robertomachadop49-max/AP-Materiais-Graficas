import 'package:isar_community/isar.dart';
import 'venda.dart';

part 'pagamento.g.dart';

@collection
class Pagamento {
  Id id = Isar.autoIncrement;
  int vendaId = 0;
  int? clienteId;
  double valor = 0;

  @enumerated
  FormaPagamento formaPagamento = FormaPagamento.pix;

  DateTime data = DateTime.now();
  String observacao = '';
}
