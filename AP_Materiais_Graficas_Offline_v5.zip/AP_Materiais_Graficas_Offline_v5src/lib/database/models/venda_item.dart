import 'package:isar_community/isar.dart';

part 'venda_item.g.dart';

@embedded
class VendaItem {
  int produtoId = 0;
  String produtoNome = '';
  int quantidade = 0;
  double precoUnitario = 0;
  double subtotal = 0;
}
