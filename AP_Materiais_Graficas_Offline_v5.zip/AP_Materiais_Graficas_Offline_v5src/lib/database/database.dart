import 'package:isar_community/isar.dart';
import 'package:path_provider/path_provider.dart';

import 'models/produto.dart';
import 'models/cliente.dart';
import 'models/venda.dart';
import 'models/pagamento.dart';
import 'models/saida.dart';

class DatabaseService {
  static Isar? _db;

  static Future<void> init() async {
    if (_db != null) return;
    final dir = await getApplicationDocumentsDirectory();
    _db = await Isar.open(
      [
        ProdutoSchema,
        ClienteSchema,
        VendaSchema,
        PagamentoSchema,
        SaidaSchema,
      ],
      directory: dir.path,
    );
  }

  static Isar get db {
    if (_db == null) {
      throw StateError('Banco de dados ainda não inicializado.');
    }
    return _db!;
  }
}
